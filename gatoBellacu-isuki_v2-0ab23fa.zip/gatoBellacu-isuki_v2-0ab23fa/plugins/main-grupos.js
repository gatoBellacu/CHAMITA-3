
let handler = async (m, { conn }) => {

m.reply(`*Hola!, te invito a unirte a los grupos oficiales de del Bot para convivir con la comunidad :D*

1- Miku Bot | OFC
▢ https://chat.whatsapp.com/GPzrXtKmgQz5B2UjxspMPO

2- Miku Bot | OFC II
▢ https://chat.whatsapp.com/BZM0LAq96G41u1iN5EV0Q7

3- Miku Bot | OFC III
▢ https://chat.whatsapp.com/IF9dreZSFsr5oz7nRtByiO

4- 🍓꙰𝐒𝐭𝐢𝐜𝐤𝐞𝐫𝐬 𝐲 𝐋𝐢𝐧𝐤𝐬 𝐁𝐲 𝐋𝐚𝐬 𝐐𝐮𝐢𝐧𝐭𝐢𝐥𝐥𝐢𝐳𝐚𝐬 °⃟᮪݇⃟⃟🍁
▢ https://chat.whatsapp.com/JWMjlI8cmQpIhO3ecEpJi8

─────────────
≡ Enlaces anulados? entre aquí! 

Mi número: http://wa.me/5218261275256`)

}
handler.help = ['grupos']
handler.tags = ['main']
handler.command = ['grupos', 'groupdylux', 'dxgp', 'dygp', 'gpdylux', 'support'] 

export default handler